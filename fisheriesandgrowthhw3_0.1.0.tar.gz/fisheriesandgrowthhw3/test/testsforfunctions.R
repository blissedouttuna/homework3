library(devtools)
library(testthat)

#testing for output expectations

fisheries_summary(price=prices, catches=example_catch)
expect_that(fisheries_summary, equals(1000))

###Returns: Error: `x` not equal to `expected`.
Modes of target, current: function, numeric
target, current do not match when deparsed###

#expect that and testing if we are using reasonable inputs
Temp = -500
foo<- expect_that(growthrate(Temp, a= -0.4970 , b= 0.1656, c= 0.08588, d= -0.004266) <0, is_true())
## Error: 'x' isn't true.

