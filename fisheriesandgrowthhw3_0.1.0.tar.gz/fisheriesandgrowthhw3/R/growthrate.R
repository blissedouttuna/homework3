#' Growth Rate of Fish
#'
#' return the specific growth rate of a cod given its Temperature
#' @param Temp is the water temperature in Celsius
#' @param a is a parameter
#' @param b is a parameter
#' @param c is a parameter
#' @param d is a parameter
#' @return the growth rate of the fish species
#' @references Growth model for Atlantic cod (Gadus morhua): Effects of temperature and body weight on growth rate by Bjorn Bjornsson, Agnar Steinarsson, Tomas Arnason. DOI: 10.1016/j.aquaculture.2007.06.026

growthrate = function(Temp, a, b, c, d){
  result = a+(b*Temp)+(c*(Temp^2))+(d*(Temp^3))
  result
}

