#' Fisheries catches in Michigan
#'
#' Data was gathered from the main ports from the months of July to September 2015. It     includes the location and the total amount of fish caught in this area
#'
#' @format a data fram with 5 rows and 6 columns
#' \itemize {
#' \fish is the fish species caught
#' \Mackinac_Island is a location
#' \Beaver_Island is a location
#' \Black_River is a location
#' \Saginaw_Bay is a location
#' \Y_Camp_Lake is a location
#' }
#' @source this data was randomized and generated
#' @author Josh
"catches"
