#' fisheries_summary
#'
#' return revenue and catch information for different locations
#' @param prices is a table with price for each fish
#' @param catches is a table with number of fish caught, location in columns, fish in rows
#' @param plot plot results default is FALSE
#' @return list with
#' \describe{
#' \item{dominant_fish_location}{revenue by location}
#' \item{total}{total revenue over all locations}
#' \item{p}{ggplot plot}
#' }

fisheries_summary = function(prices, catches, plot=FALSE) {
  catches = as.data.frame(catches)
  nloc = ncol(catches)
  catches$fish = rownames(catches)

  dominant = catches$fish[apply(catches[,1:nloc],2, which.max)]
  dominant = as.data.frame(dominant)
  dominant$location = colnames(catches[,1:nloc])

  catches_reordered = gather(catches, key="location", value= "size", -fish)

  catches_reordered = left_join(catches_reordered, prices)

  catches_reordered = catches_reordered %>% mutate(revenue = price*size)
  revenue_location = catches_reordered %>%
    group_by(location) %>%
    summarize_at(vars(revenue), sum)
  totalr= sum(catches_reordered$revenue)

  if (plot) {
    lb = sprintf("The total revenue is %d dollars", totalr)
    p = ggplot(revenue_location, aes(location, revenue, fill=location))+geom_col()+
      labs(y="revenue in dollars")+annotate("text", x=2, y=60000, label=lb, col="red")
  }
  else p=NULL

  return(list(dominant_fish_location=dominant, revenue_location=revenue_location, totalr=totalr, plot=p))
}
