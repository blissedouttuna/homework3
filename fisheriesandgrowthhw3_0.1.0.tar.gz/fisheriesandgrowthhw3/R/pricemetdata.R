#' Market prices for different fish species
#'
#' Data was pulled from fish market prices in Detroit, Michigan.
#'
#' @format A data fram with 5 rows and 2 columns that include different fish species and the relative market value
#' \itemize{
#' \price is the cost for each fish species
#' \fish is the fish species
#' }
#' @source\ made up
#'
"pricemetdata"

